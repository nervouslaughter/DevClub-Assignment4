console.log("Moodle+ successfully loaded!");
const login_element = document.querySelector(".loginpanel"); // Fill the selector for the login element in ""
let login_text = login_element.innerText;

let question = login_text.split(' '); // Use split and array operations on the login_text string to extract the question
console.log(question);
let answer=0;
if (question[1+5]==='add'){
    answer=Number(question[2+5])+Number(question[4+5]);
}
if (question[1+5]=='subtract'){
    answer=Number(question[2+5])-Number(question[4+5]);
}
if (question[1+5]=='enter'){
    if (question[2+5]=='second'){
        answer=question[6+5];
    }
    if (question[2+5]=='first'){
        answer=question[4+5];
    }
}
console.log(answer);
 // Use if conditions to parse the question and calculate the answer. Make cases for all types of captcha asked

const captcha_input_element = document.querySelector("#valuepkg3"); // Fill the selector for the captcha input element in ""
captcha_input_element.value = answer;
document.getElementById("loginbtn").submit();
