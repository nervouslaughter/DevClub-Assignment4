console.log("Loaded script.js");
